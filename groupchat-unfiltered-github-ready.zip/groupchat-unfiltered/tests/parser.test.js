import test from 'node:test';import assert from 'node:assert/strict';
import {parseWhatsApp,buildStats,renameAndMerge,demoMessages} from '../parser.js';
test('iPhone WhatsApp export multiline, emoji, stats',()=>{
 const text='[25/10/2025, 09:30:01] Alex: Hi there 😂\nline two\n[25/10/2025, 09:31:01] Jamie: A reply\n[26/10/2025, 18:00:00] Alex: Pub later?';
 const arr=parseWhatsApp(text);assert.equal(arr.length,3);assert.equal(arr[0].text,'Hi there 😂\nline two');const s=buildStats(arr);assert.equal(s.total,3);assert.equal(s.participants[0].count,2);assert.equal(s.bestStreak,2);assert.equal(s.recordCount,2);
});
test('Android export and American dates',()=>{
 const txt='10/25/25, 9:30 AM - Alex: Hello\n10/25/25, 9:32 AM - Jo: hi';
 assert.equal(parseWhatsApp(txt,{monthFirst:true}).length,2);
});
test('rename and merge and demo',()=>{
 const demo=demoMessages();assert.ok(demo.length>300);const r=renameAndMerge(demo,{Alex:'Jamie'});assert.equal(buildStats(r).participants.length,3);
});
