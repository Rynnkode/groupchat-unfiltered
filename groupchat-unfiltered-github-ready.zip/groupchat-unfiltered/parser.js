/* Pure WhatsApp text parsing and statistics. No content leaves the browser. */
const DATE_HEAD = [
  /^\[?(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4}),?\s+(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM|am|pm)?\]?\s*(?:-|–)?\s*(.*)$/,
  /^(\d{4})[\/\-.](\d{1,2})[\/\-.](\d{1,2})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(?:-|–)\s*(.*)$/
];
const SYSTEM = /^(?:messages and calls are end-to-end|you (?:created|added|changed|left|joined)|\w+ (?:added|joined|left|removed|changed)|this message was deleted|security code changed|\d+ messages? omitted|missed (?:voice|video) call)/i;
const OMITTED = /^(?:<media omitted>|image omitted|video omitted|audio omitted|sticker omitted|gif omitted|document omitted|contact card omitted|this message was deleted|‎?<attached:|‎?image omitted)/i;
function parseHead(line, preferMonthFirst=false) {
  const clean = line.replace(/[\u200e\u200f\u202a-\u202e]/g,'').trim();
  for (let i=0;i<DATE_HEAD.length;i++) {
    const m=clean.match(DATE_HEAD[i]); if(!m) continue;
    let [,a,b,c,hh,mm,ss,amp,tail] = m;
    if (i === 1) { tail=m[7]; amp=null; ss=m[6]; mm=m[5]; hh=m[4]; c=m[3]; b=m[2]; a=m[1]; }
    const iso=i===1; let yr=+(iso?a:c), mo=+(iso?b:(preferMonthFirst?a:b)), day=+(iso?c:(preferMonthFirst?b:a));
    if(yr<100) yr+=yr>=80?1900:2000;
    let h=+hh;if(amp){ h=(h%12)+(/pm/i.test(amp)?12:0); }
    const dt=new Date(yr,mo-1,day,h,+mm,+(ss||0));
    if (!Number.isFinite(dt.getTime())||dt.getFullYear()!==yr||dt.getMonth()!==mo-1||dt.getDate()!==day) continue;
    let sep=tail.indexOf(': ');
    if(sep<1 || sep>85) continue;
    const sender=tail.slice(0,sep).trim(), text=tail.slice(sep+2).trim();
    if(!sender || SYSTEM.test(sender))continue;
    return {date:dt,sender,text};
  }
  return null;
}
export function parseWhatsApp(text, {monthFirst=false}={}) {
  if(!text || typeof text!=='string')throw Error('Select a WhatsApp .txt export first.');
  const lines=text.replace(/\r\n?/g,'\n').split('\n'); const messages=[];let current=null;
  for(const line of lines){
    const next=parseHead(line,monthFirst);
    if(next){if(current) messages.push(current);current=next;}
    else if(current && line.length){current.text+='\n'+line;}
  }
  if(current)messages.push(current);
  const clean=messages.filter(m=>m.text.trim()&&!OMITTED.test(m.text.trim()));
  clean.sort((a,b)=>a.date-b.date);
  if(!clean.length) throw Error('No WhatsApp messages were detected. Export a chat WITHOUT media, or check the date-format setting.');
  return clean;
}
export async function readChatFile(file) {
  if(!file)throw Error('Choose a WhatsApp export file.');
  if(file.size>60*1024*1024)throw Error('This file is too large. Please export without media (limit 60 MB).');
  if(/\.txt$/i.test(file.name))return await file.text();
  if(/\.zip$/i.test(file.name)){
    // JSZip is bundled locally, so private conversation files never rely on a remote script.
    if(!globalThis.JSZip) throw Error('The built-in ZIP reader could not load. Try refreshing or importing the .txt file.');
    const zip=await JSZip.loadAsync(file);const entries=Object.values(zip.files).filter(e=>!e.dir&&/\.txt$/i.test(e.name)&&!e.name.startsWith('__MACOSX'));
    entries.sort((a,b)=>Number(/_chat\.txt$/i.test(b.name))-Number(/_chat\.txt$/i.test(a.name)));
    if(!entries.length)throw Error('No .txt chat found in the ZIP. Export WhatsApp without media.');
    return await entries[0].async('string');
  }
  throw Error('Please upload a WhatsApp .txt or .zip export.');
}
function dayKey(date){return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;}
function median(nums){if(!nums.length)return null;const s=nums.sort((a,b)=>a-b),mid=Math.floor(s.length/2);return s.length%2?s[mid]:(s[mid-1]+s[mid])/2;}
const STOP=new Set('a an and are as at be been but by can could did do does for from had has have he her hers him his i if in into is it its just me my no not of on or our ours she so some than that the their them there these they this those to too up us was we were what when where which who why will with would you your yours yeah yes okay ok lol haha like really get got going gonna im ive dont didnt its thats hes shes youre wasnt wont cant about then now well very more all one two also oh ur u x xx xxx'.split(' '));
export function buildStats(messages) {
  if(!messages.length)throw Error('No messages to analyse.');
  const participantCounts=new Map(), dayCounts={},hourCounts=Array(24).fill(0),words=new Map(),emojiCounts=new Map();
  const byPerson=new Map(), starts=new Map(), replies=new Map();let recordDay=null, recordCount=0,longest=messages[0];
  for(let i=0;i<messages.length;i++){
    const m=messages[i];participantCounts.set(m.sender,(participantCounts.get(m.sender)||0)+1);
    if(!byPerson.has(m.sender))byPerson.set(m.sender,[]);byPerson.get(m.sender).push(m);
    const d=dayKey(m.date);dayCounts[d]=(dayCounts[d]||0)+1;if(dayCounts[d]>recordCount){recordCount=dayCounts[d];recordDay=d;}
    hourCounts[m.date.getHours()]++;
    const count=(m.text.trim().match(/\S+/g)||[]).length;if(count>(longest.text.match(/\S+/g)||[]).length)longest=m;
    for(const word of m.text.toLowerCase().match(/[\p{L}][\p{L}'’-]{2,}/gu)||[]){const w=word.replace(/^['’]|['’]$/g,'');if(!STOP.has(w)&&!/^https?/.test(w))words.set(w,(words.get(w)||0)+1);}
    for(const em of m.text.match(/\p{Extended_Pictographic}(?:\ufe0f|\u200d\p{Extended_Pictographic})*/gu)||[])emojiCounts.set(em,(emojiCounts.get(em)||0)+1);
    if(i===0 || (m.date-messages[i-1].date)>6*3600000)starts.set(m.sender,(starts.get(m.sender)||0)+1);
    if(i>0 && m.sender!==messages[i-1].sender){let minutes=(m.date-messages[i-1].date)/60000;if(minutes>=0&&minutes<=240){if(!replies.has(m.sender))replies.set(m.sender,[]);replies.get(m.sender).push(minutes);}}
  }
  const participants=[...participantCounts].sort((a,b)=>b[1]-a[1]).map(([name,count],i)=>({name,count,pct:Math.round(count/messages.length*100),startCount:starts.get(name)||0,replyMinutes:median(replies.get(name)||[]),color:['#ec8edf','#ffc928','#76ddad','#94afff','#ff9972','#b99aee','#5ec8dc'][i%7]}));
  const activeKeys=Object.keys(dayCounts).sort();let streak=0,bestStreak=0,longestSilence=0;
  for(let i=0;i<activeKeys.length;i++){
    if(i===0){streak=1;bestStreak=1;continue;}
    const delta=Math.round((new Date(activeKeys[i]+'T12:00:00')-new Date(activeKeys[i-1]+'T12:00:00'))/86400000);
    streak=delta===1?streak+1:1;bestStreak=Math.max(streak,bestStreak);longestSilence=Math.max(longestSilence,Math.max(0,delta-1));
  }
  const rank=map=>[...map].sort((a,b)=>b[1]-a[1]);
  return {total:messages.length,participants,dayCounts,hourCounts,recordDay,recordCount,bestStreak,longestSilence,
    commonWords:rank(words).slice(0,8),commonEmojis:rank(emojiCounts).slice(0,8),first:messages.slice(0,5),last:messages.slice(-5),longest,
    earliest:messages[0].date,latest:messages.at(-1).date,activeDays:activeKeys.length,starts:Object.fromEntries(starts),replyTimes:Object.fromEntries([...replies].map(([k,v])=>[k,median(v)])),byPerson};
}
export function renameAndMerge(messages,aliasMap){return messages.map(m=>({...m,sender:(aliasMap[m.sender]||m.sender).trim()||m.sender}));}
export function demoMessages(){
  const people=['Alex','Jamie','Taylor','Morgan'];const topics=[
  'Is everyone alive after last night? 😂','Booking the restaurant now, does 8pm work?','Who ordered 12 pizzas?','We need to talk about the office coffee situation.','Absolutely not, that is criminal behaviour 😂','I have screenshots and questions 👀','Saturday plans?','Someone please explain the mystery plant incident.','I cannot believe you actually did that','Fine. Pub at 7 🍻','This group needs adult supervision.','Happy birthday! 🎉','I am bringing snacks.','This is why we cannot have nice things.','Who is coming to the football?','We have an emergency: no biscuits.'];
  const arr=[];let t=new Date(2026,0,7,11,0).getTime();for(let i=0;i<420;i++){
    t+=Math.floor((i%17===0?300:1+(i*13)%47))*60000;
    arr.push({date:new Date(t),sender:people[(i*11+Math.floor(i/8))%4],text:topics[(i*7+Math.floor(i/11))%topics.length]});
  }return arr;
}
