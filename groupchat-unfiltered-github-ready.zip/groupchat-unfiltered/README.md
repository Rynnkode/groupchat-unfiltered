# Groupchat Unfiltered

A free, mobile-first WhatsApp chat analyser and satirical group-chat report site, independently implemented from screenshots and user requirements. No Lovable, subscriptions, database, accounts or hosting costs required.

## Features

- iPhone and Android WhatsApp `.txt` exports, plus `.zip` exports (bundled offline JSZip ZIP reader).
- Multiline messages, AM/PM and day/month or month/day timestamps, sender detection, participant renaming and merging.
- Seven-screen interactive reveal: activity calendar, talk share, conversation starts, median reply time, busiest day, streak, silence, hourly activity, longest message, first and last messages, words, and emojis.
- Long magazine-style report with chapters, participant profiles, chat excerpts, and a verdict.
- Fully free, offline-friendly template-driven local report (no network request for chat analysis).
- **Optional** AI-written chapters via a Google Gemini API key. Selecting AI and consenting sends a sampled subset of chat messages to Google; Google's free-tier eligibility and limits apply. This is not required to use the site.
- Self-contained `.html` report download and browser print / Save as PDF.
- Private by default. No account and no remote transcript storage.

## Try it

Open `index.html` from a web server (GitHub Pages or `python3 -m http.server 8000`). For local test use http://localhost:8000 and click **Try a live demo**. The demo uses fictional data.

## Publish free with GitHub Pages

1. Create a new **public** repository at https://github.com/new (suggested name: `groupchat-unfiltered`).
2. Upload all the files from this project to the repository's `main` branch. Keep `main.js`, `parser.js`, `report.js`, and `styles.css` beside `index.html`.
3. Go to **Settings → Pages → Build and deployment**, choose **Deploy from a branch**, `main`, and `/ (root)`. Save.
4. Open `https://YOUR-USERNAME.github.io/groupchat-unfiltered/` once GitHub Pages has deployed.

No npm install or build step is needed. Tests run with `npm test` (Node 22+). `jszip.min.js` is a bundled third-party library distributed under its own MIT licence (see `JSZIP-LICENSE.md`).

## How private is this?

Local mode: text is held in browser memory while the page is open. It is not uploaded, and there is no backend or tracking. The interface never claims a stored report can be deleted remotely, because none is stored. Save an HTML copy yourself if desired.

ZIP support: the JSZip library is bundled with the site. Your ZIP and message text never need to leave your device for local mode.

AI mode: off by default; requires explicit consent and a personal Gemini API key. A sample (up to 300 chat messages), member names and statistics are sent to the Google Gemini API. The key is kept only in the page's JavaScript memory during the request and cleared afterward; users should check the provider's data and free-tier terms and get permission from participants.

## Limits and accuracy

- It is an original lookalike in *concept and flow*, not a copy of What Brandon Thinks source code, product trademarks, or proprietary model output.
- Reply times are median cross-participant responses within 4 hours. Conversation starts are messages after a gap of **more than six hours**.
- The locally generated report is deterministic, evidence-led comic prose, not a language-model equivalent to the example site's reports. Use the optional AI mode for original narrative writing.
- Media, deleted messages, chats in unsupported export formats, and very large attachments aren't processed.
- Analysis is for entertainment. Inferences about another person's motives or character are not facts.

## Tech

Plain semantic HTML, modular modern JavaScript, CSS. No React, build system, database, or paid hosting. MIT licensed.
