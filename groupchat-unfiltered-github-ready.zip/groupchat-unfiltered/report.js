/* Evidence-led local narrative generator, plus opt-in Gemini prose generation. */
import {buildStats} from './parser.js';
const THEMES=[
  {name:'Workplace warfare',icon:'🏢',pattern:/\b(work|boss|manager|office|meeting|hr|job|staff|grievance|colleague|client|shift|compliance|salary)\b/i,
   headline:'The Corporate Soap Opera',intro:'Some group chats discuss their careers. This one appears to run a shadow tribunal with a side business in commentary.'},
  {name:'The social calendar',icon:'🍻',pattern:/\b(pub|beer|drunk|wine|pint|party|club|hangover|shots|drinks|cocktail|sober)\b/i,
   headline:'The Department of Questionable Decisions',intro:'The social programme is ambitious, the self-preservation strategy less so.'},
  {name:'Grand plans',icon:'✈️',pattern:/\b(holiday|trip|flight|hotel|barcelona|abroad|travel|booked|airport|weekend|train)\b/i,
   headline:'International Diplomacy, Budget Airline Edition',intro:'A simple proposal to leave the house has developed the operational complexity of a multinational summit.'},
  {name:'Romantic catastrophes',icon:'💌',pattern:/\b(date|boyfriend|girlfriend|kiss|crush|ex|relationship|flirt|love|fancy|marry)\b/i,
   headline:'The Ministry of Romantic Affairs',intro:'The relationship-advice bureau is apparently open twenty-four hours and requires no qualifications.'},
  {name:'Culinary incidents',icon:'🍕',pattern:/\b(food|pizza|dinner|lunch|chips|takeaway|chicken|restaurant|coffee|breakfast|biscuits|snack)\b/i,
   headline:'The Great Catering Emergency',intro:'A troubling percentage of the group’s mental bandwidth is devoted to what is, in the end, lunch.'},
  {name:'Sporting delusions',icon:'⚽',pattern:/\b(football|match|team|saints|pompey|arsenal|chelsea|united|goal|game|sport)\b/i,
   headline:'The Sporting Department of Unsolicited Confidence',intro:'Athletic expertise is in abundant supply, particularly among those comfortably seated.'},
  {name:'Absolute chaos',icon:'🔥',pattern:/\b(drama|chaos|disaster|idiot|insane|crazy|mad|what happened|unbelievable|screenshot|fight|trouble|emergency)\b/i,
   headline:'Incidents, Accidents and General Nonsense',intro:'The unofficial incident log is extensive, and almost nobody seems interested in reducing the number of incidents.'},
  {name:'Organisation theatre',icon:'📅',pattern:/\b(when|where|what time|tomorrow|today|saturday|sunday|friday|plans|coming|meet|ready|late)\b/i,
   headline:'The Logistics Committee That Never Was',intro:'Despite a staggering quantity of correspondence, agreeing a time and place remains a heroic undertaking.'}
];
const prettyDate=d=>new Date(d).toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'});
const pick=(arr,n=3)=>{if(arr.length<=n)return arr;const step=arr.length/n;return Array.from({length:n},(_,i)=>arr[Math.min(arr.length-1,Math.floor((i+0.6)*step))]);};
export function storyData(messages,stats,options={}){
  const group=options.group||'this group';
  const tone=options.tone||'sharp';
  const flavour=tone==='soft'?{
    chapter:'Somehow, between the jokes and the logistical negotiations, everyone is still very fond of each other.',
    opening:'A lively little archive of friendships, arrangements and the occasional glorious misunderstanding.',
    profile:'One more very human contribution to a very human conversation.',
    verdict:'A surprisingly lovely way to keep a group together.'
  }:tone==='playful'?{
    chapter:'At this stage the group needs a secretary, a whistle and possibly a sensible adult.',
    opening:'The atmosphere is best described as a committee meeting hosted inside a bouncy castle.',
    profile:'An important contribution to a group effort that nobody is quite supervising.',
    verdict:'An impressive amount of companionship disguised as organised nonsense.'
  }:{
    chapter:'The group has all the administrative competence of a supermarket trolley with one broken wheel.',
    opening:'What should have been a messaging service has become an ongoing public inquiry with no qualified witnesses.',
    profile:'The group, somehow, has survived another encounter with their formidable decision-making skills.',
    verdict:'A heroic commitment to documenting the collapse of basic coordination.'
  };
  const suspects=stats.participants;
  const top=suspects[0],second=suspects[1]||top;
  const chapters=THEMES.map(t=>({
    ...t, hits:messages.filter(m=>t.pattern.test(m.text)&&m.text.length<900)
  })).filter(t=>t.hits.length>=2).sort((a,b)=>b.hits.length-a.hits.length).slice(0,5).map(t=>({
    title:t.icon+' '+t.headline,theme:t.name,quotes:pick(t.hits,3),
    paragraphs:[t.intro,
      `${t.hits.length.toLocaleString('en-GB')} messages in this archive touch on ${t.name.toLowerCase()}. That is ${Math.round(t.hits.length/messages.length*100)}% of the recorded conversation: not necessarily a cause for alarm, but certainly enough material for a committee hearing.`,
      `The exhibits below are verbatim messages from the export, not an invented reenactment. Reality, evidently, has been doing the writing.`,
      flavour.chapter]
  }));
  if(!chapters.length)chapters.push({title:'🕵️ The Ordinary, the Extraordinary and the Group Chat',theme:'Everyday chat',quotes:pick(messages.filter(m=>m.text.length>10&&m.text.length<600),3),paragraphs:[
    'Every group needs somewhere to store its collective nonsense. This one has archived it with extraordinary discipline.',
    'There may be no single overriding scandal, but there are more than enough small decisions to warrant a documentary.',
    'The receipts, as always, are below.']});
  const profiles=suspects.slice(0,12).map((p,i)=>{
    const m=messages.filter(x=>x.sender===p.name);const common=THEMES.map(t=>({title:t.name,count:m.filter(x=>t.pattern.test(x.text)).length})).sort((a,b)=>b.count-a.count)[0];
    const role=i===0?'The Chief Correspondent':i===1?'The Deputy Director of Discourse':p.replyMinutes!==null&&p.replyMinutes<2?'The Rapid Response Unit':i===2?'The Chaos Consultant':'The Occasional Witness';
    return {name:p.name,title:role,emoji:['👑','🕶️','🧨','🎭','📣','🦊','🫡'][i%7],quote:pick(m.filter(x=>x.text.length>9&&x.text.length<170),1)[0],paragraph:`${p.name} contributed ${p.count.toLocaleString('en-GB')} messages (${p.pct}% of the total). Their most noticeable recurring topic is ${common?.count?common.title.toLowerCase():'the ongoing conversation'}; ${p.startCount} fresh conversation${p.startCount===1?'':'s'} began with them. ${p.replyMinutes===null?'The archive does not give enough cross-person replies to estimate response time.':`Their median cross-person reply is about ${Math.round(p.replyMinutes)} minute${Math.round(p.replyMinutes)===1?'':'s'}.`} ${flavour.profile}`};
  });
  const title= `${group}: A Completely Unnecessary Investigation`;
  const intro=[
    `I have examined ${stats.total.toLocaleString('en-GB')} messages exchanged between ${stats.participants.length} people from ${prettyDate(stats.earliest)} to ${prettyDate(stats.latest)}. Most historians wait centuries before examining a civilisation's correspondence. Unfortunately, this lot exported theirs.`,
    `The first thing to know about ${group} is that ${top.name} accounts for ${top.pct}% of the traffic. ${second.name} is not far behind at ${second.pct}%. In other words, this is a group conversation in roughly the same way that a parliamentary debate is a quiet evening in.`,
    `${flavour.opening} I found running jokes, recurring themes, impressive response times and enough raw material to keep a documentary editor employed. Let's inspect the evidence.`
  ];
  const verdict=`This chat logged ${stats.activeDays} active days, a longest active streak of ${stats.bestStreak} days, and ${stats.recordCount} messages on its busiest day (${prettyDate(stats.recordDay+'T12:00:00')}). An improbable administrative achievement for people who may struggle to choose a restaurant. The verdict: ${flavour.verdict}`;
  return {title,subtitle:'An entirely unofficial audit of the group chat',intro,chapters,profiles,verdict,group,mode:'local'};
}
export async function aiStory(messages,stats,options={}){
  const apiKey=(options.apiKey||'').trim();if(!apiKey)throw Error('Enter a Gemini API key to use optional AI writing.');
  const base=storyData(messages,stats,options);
  const candidates=messages.filter(m=>m.text.length>6&&m.text.length<420&&!/password|passcode|credit card|bank account|sort code|national insurance/i.test(m.text));
  // A sample across the archive plus topic-relevant records. Sent only after explicit opt in.
  const sample=pick(candidates,Math.min(300,candidates.length));
  const selected=sample.map(m=>`${new Date(m.date).toISOString().slice(0,10)} | ${m.sender}: ${m.text.replace(/\s+/g,' ').slice(0,280)}`).join('\n');
  const detailed=stats.participants.map(p=>`${p.name}: ${p.count} messages, ${p.pct}%, ${p.startCount} starts`).join('; ');
  const prompt=`You are a sharp but affectionate British satirical columnist writing a humorous group-chat autopsy. Use UK English. Tone: ${options.tone||'savage'}. This is playful entertainment, not a factual accusation. Only describe events supported by exact quotes from the chat sample; never fabricate incidents, actions, nicknames, or direct quotes. Do not invent protected, medical, sexual or criminal characteristics about individuals. You may make witty observations based on actual chat snippets. Avoid slurs and threats. Ensure every section is specific to this group, not generic filler.\n\nGroup: ${options.group||'The group'}\nStatistics: ${stats.total} messages; participants ${detailed}; first ${prettyDate(stats.earliest)}; latest ${prettyDate(stats.latest)}.\n\nSampled real messages (in chronological spread):\n${selected}\n\nReturn STRICT JSON with keys: title (punchy, <100 chars), intro (array of 3 witty paragraphs), chapters (array of 4-6 objects with title, paragraphs array of 2-4 substantial paragraphs, quotes array of objects {sender,text}, each quote an EXACT message excerpt), profiles (array for EVERY named participant with {name,title,emoji,paragraph,quote:{sender,text}}; profile descriptions based only on evidence), verdict (1 paragraph). Keep quotes accurate and avoid any claim not supported by the sampled chat. Output valid JSON only.`;
  const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),90000);
  try{
    const model=options.model||'gemini-2.5-flash';
    const response=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,{
      method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':apiKey},signal:controller.signal,
      body:JSON.stringify({contents:[{role:'user',parts:[{text:prompt}]}],generationConfig:{responseMimeType:'application/json',temperature:0.85,maxOutputTokens:9000}})
    });
    const payload=await response.json();if(!response.ok)throw Error(payload.error?.message||`Gemini returned HTTP ${response.status}`);
    const jsonText=(payload.candidates?.[0]?.content?.parts||[]).map(p=>p.text||'').join('').replace(/^```(?:json)?\s*|\s*```$/g,'');
    const result=JSON.parse(jsonText);
    if(!Array.isArray(result.chapters)||!Array.isArray(result.intro))throw Error('The AI returned an incomplete report. Try generating again.');
    const validMessages=new Set(messages.map(m=>m.sender+'\u0000'+m.text));
    // Ignore invented quotations: present only known original text or matching substrings.
    const findReal=q=>{if(!q||!q.sender||!q.text)return null;const hit=messages.find(m=>m.sender===q.sender&&(m.text.includes(q.text)||q.text.includes(m.text)));return hit?{sender:hit.sender,text:hit.text,date:hit.date}:null;};
    return {...base,...result,mode:'ai',chapters:result.chapters.slice(0,7).map(ch=>({title:String(ch.title||'The evidence'),paragraphs:(ch.paragraphs||[]).map(String).slice(0,5),quotes:(ch.quotes||[]).map(findReal).filter(Boolean).slice(0,4)})),profiles:base.profiles.map(p=>{const a=(result.profiles||[]).find(q=>q.name===p.name);return a?{...p,title:String(a.title||p.title),paragraph:String(a.paragraph||p.paragraph),emoji:String(a.emoji||p.emoji),quote:findReal(a.quote)||p.quote}:p;})};
  }finally{clearTimeout(timeout);}
}
